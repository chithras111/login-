
from __future__ import unicode_literals

from django.shortcuts import render

def home(request):
    if (request.method == "POST"):
        return render(request,"account.html")

    return render(request,"rony.html")


def create(request):
    if (request.method == "POST"):
        return render(request,"account.html")
    return render(request, "create.html")


def forgorpsw(request):
    if (request.method == "POST"):
        return render(request, "changepsw.html")
    return render(request, "forgorpsw.html")


def change(request):
    if (request.method == "POST"):
        return psw(request)
    return render(request, "changepsw.html")
def psw(request):
    return render(request, "psw.html")