function validate()
{
var psw=document.getElementById('psw').value;
var rpsw=document.getElementById('rpsw').value;

   if(psw=="" || psw!=rpsw)
    {
    document.getElementById('s7').innerHTML="<p style='color:red;'>Password can't be empty and  should be same</p>";
    return false;
    }
 }




